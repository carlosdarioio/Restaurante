<?php
//Pantalla principal de controladores
$show_errors = true;
if($show_errors){
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
}

include "controller/Core.php";
include "controller/View.php";
include "controller/Module.php";
include "controller/Database.php";
include "controller/Executor.php";

//labels/valores
include "controller/forms/lbForm.php";
include "controller/forms/lbInputText.php";
include "controller/forms/lbInputPassword.php";
include "controller/forms/lbValidator.php";


include "controller/Model.php";
include "controller/Bootload.php";
include "controller/Action.php";

//Form/ajax request
include "controller/Request.php";


//cookies y valoresz
include "controller/Get.php";
include "controller/Post.php";
include "controller/Cookie.php";
include "controller/Session.php";
include "controller/Lb.php";

// forms
include "controller/Form.php";
include "controller/class.upload.php";


?>