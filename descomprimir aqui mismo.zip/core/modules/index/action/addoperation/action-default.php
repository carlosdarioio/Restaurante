
<?php
// print_r($_POST);
$product = ProductData::getById($_POST["product_id"]);

$operation = new OperationData();
$operation->stock_id =1;
$operation->price_in =$product->price_in;
$operation->price_out =$product->price_out;

$operation->product_id = $_POST["product_id"];
$operation->operation_type_id =1;
$operation->is_oficial =1;
$operation->q = $_POST["q"];
$operation->sell_id = $_POST["sell_id"];
$operation->add();
header("Location: index.php?view=onesell&id=$_POST[sell_id]");
// header("Location: index.php?view=categories");
?>