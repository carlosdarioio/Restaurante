<?php
if(isset($_GET["opt"]) && $_GET["opt"]=="add"){
$grade = new CityData();
$grade->name = $_POST["name"];
$grade->add();
Core::redir("./?view=cities&opt=all");
}
else if(isset($_GET["opt"]) && $_GET["opt"]=="update"){
if(count($_POST)>0){
	$user = CityData::getById($_POST["user_id"]);
	$user->name = $_POST["name"];
	$user->update();
Core::redir("./?view=cities&opt=all");
}
}
else if(isset($_GET["opt"]) && $_GET["opt"]=="del"){
$category = CityData::getById($_GET["id"]);
$category->del();
Core::redir("./?view=cities&opt=all");

}






?>