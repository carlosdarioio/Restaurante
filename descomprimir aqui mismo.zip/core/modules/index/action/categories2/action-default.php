<?php
if(isset($_GET["opt"]) && $_GET["opt"]=="add"){
$grade = new Category2Data();
$grade->name = $_POST["name"];
$grade->add();
Core::redir("./?view=categories2&opt=all");
}
else if(isset($_GET["opt"]) && $_GET["opt"]=="update"){
if(count($_POST)>0){
	$user = Category2Data::getById($_POST["user_id"]);
	$user->name = $_POST["name"];
	$user->update();
Core::redir("./?view=categories2&opt=all");
}
}
else if(isset($_GET["opt"]) && $_GET["opt"]=="del"){
$category = Category2Data::getById($_GET["id"]);
$category->del();
Core::redir("./?view=categories2&opt=all");

}






?>