<?php
if(isset($_GET["opt"]) && $_GET["opt"]=="add"){
$grade = new ComunData();
$grade->name = $_POST["name"];
$grade->add();
Core::redir("./?view=comuns&opt=all");
}
else if(isset($_GET["opt"]) && $_GET["opt"]=="update"){
if(count($_POST)>0){
	$user = ComunData::getById($_POST["user_id"]);
	$user->name = $_POST["name"];
	$user->update();
Core::redir("./?view=comuns&opt=all");
}
}
else if(isset($_GET["opt"]) && $_GET["opt"]=="del"){
$category = ComunData::getById($_GET["id"]);
$category->del();
Core::redir("./?view=comuns&opt=all");

}






?>