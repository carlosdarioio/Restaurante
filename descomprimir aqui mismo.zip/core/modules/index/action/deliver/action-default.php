<?php

if(isset($_GET["id"])){
$sell = SellData::getById($_GET["id"]);
$sell->d_id=1;

$operations = OperationData::getAllProductsBySellId($_GET["id"]);
foreach ($operations as $op) {
	$op->operation_type_id=2;
	$op->update_type();
}


///////////////////////////////////////////////////////////////
$products = OperationData::getAllProductsBySellId($sell->id);
foreach ($products as $prod) {
	$product = ProductData::getById($prod->product_id);
	if($product->use_ingredients){
		$ingredients = ProductIngredientData::getAllByProductId($prod->product_id);
		//print_r($ingredients);
		foreach($ingredients as $ing){
			$ingredient = ProductData::getById($ing->ingredient_id);
			// $q = OperationData::getQYesF($ing->ingredient_id);
			$q = OperationData::getQByStock($ing->ingredient_id,1);
			if($q>0){
				$op = new OperationData();
				$op->price_in = $ingredient->price_in;
				$op->price_out = $ingredient->price_out;
				$op->stock_id=1;
				$op->product_id = $ingredient->id ;
				$op->operation_type_id=2; // 2 - salida
				$op->sell_id=$sell->id;
				$op->q= $prod->q*$ing->q;

				$add = $op->add();			 		

			}

		}
	}
	# code...
}
///////////////////////////////////////////////////////////////

$sell->update_d();
Core::redir("./?view=bydeliver");
}
?>